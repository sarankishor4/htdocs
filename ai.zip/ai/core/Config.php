<?php
namespace AI\Core;

class Config {
    const APP_NAME = "AI Nexus";
    const APP_VERSION = "2.0.0 (Enterprise)";
    
    const DB_HOST = 'localhost';
    const DB_USER = 'root';
    const DB_PASS = '';
    const DB_NAME = 'ai_nexus';
    
    const DEPARTMENTS = [
        'ceo' => ['icon' => 'crown', 'color' => '#ffd700', 'name' => 'CEO Oracle'],
        'dev' => ['icon' => 'terminal', 'color' => '#00d2ff', 'name' => 'Dev Matrix'],
        'marketing' => ['icon' => 'rocket', 'color' => '#ff00ff', 'name' => 'Growth Engine'],
        'sales' => ['icon' => 'funnel-dollar', 'color' => '#00ff88', 'name' => 'Revenue Flow'],
        'hr' => ['icon' => 'heart', 'color' => '#ffa500', 'name' => 'Ops Pulse'],
        'finance' => ['icon' => 'vault', 'color' => '#4facfe', 'name' => 'Ledger AI'],
        'social' => ['icon' => 'hashtag', 'color' => '#7289da', 'name' => 'Social Sphere']
    ];
}
?>
