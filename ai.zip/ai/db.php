<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'ai_nexus';

// Create connection
$conn = new mysqli($host, $user, $pass);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    $conn->select_db($dbname);
}

// Create Tables
$tables = [
    "agents" => "CREATE TABLE IF NOT EXISTS agents (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) NOT NULL,
        role VARCHAR(50) NOT NULL,
        status ENUM('online', 'busy', 'offline') DEFAULT 'online',
        efficiency INT DEFAULT 100,
        last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "tasks" => "CREATE TABLE IF NOT EXISTS tasks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        agent_id INT,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        status ENUM('pending', 'active', 'completed') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "logs" => "CREATE TABLE IF NOT EXISTS logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        agent_name VARCHAR(50),
        message TEXT,
        type ENUM('info', 'warning', 'success', 'error') DEFAULT 'info',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )"
];

foreach ($tables as $name => $sql) {
    $conn->query($sql);
}

// Insert Default Agents if not exists
$check = $conn->query("SELECT COUNT(*) as count FROM agents");
$row = $check->fetch_assoc();
if ($row['count'] == 0) {
    $conn->query("INSERT INTO agents (name, role, status) VALUES 
        ('Oracle', 'CEO', 'online'),
        ('Matrix', 'Developer', 'online'),
        ('Engine', 'Marketing', 'online'),
        ('Flow', 'Sales', 'online'),
        ('Pulse', 'HR', 'online'),
        ('Ledger', 'Finance', 'online'),
        ('Sphere', 'Social', 'online')");
}

function getAgents($conn) {
    return $conn->query("SELECT * FROM agents");
}
?>
